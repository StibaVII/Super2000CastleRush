﻿using UnityEngine;
using System.Collections;

public class EnemyFly : MonoBehaviour {

    public Vector2 velocity = new Vector2(-5, 0);
    public GameObject target;
    public float enemyHealth = 10f;
    public int attackTimer = 1;
    public float enemyDamage = 1f;
    public float enemyGold = 5f;
    float timer = 0.5f;
    bool castleCollided = false;
    GameObject castle;

	// Use this for initialization
	void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {
        GetComponent<Rigidbody2D>().velocity = velocity;
        if (enemyHealth <= 0)
        {
            castle = GameObject.FindGameObjectWithTag("Fort");
            Castle Script1 = castle.GetComponent<Castle>();
            Script1.playerGold = Script1.playerGold + enemyGold;
            Destroy(target);
        }
        if (castleCollided)
        {
            timer += Time.deltaTime;
            if (timer > attackTimer)
            {
                castle = GameObject.FindGameObjectWithTag("Fort");
                Castle Script1 = castle.GetComponent<Castle>();
                Script1.castleHealth -= enemyDamage;
                Debug.Log("Castle health: " + Script1.castleHealth);
                timer = 0;
            }
        }
        
	}
    public void OnCollisionEnter2D(Collision2D col)
    {
        if (col.collider.tag == "Projectile")
        {
            
        }
        if (col.collider.tag == "Fort")
        {
            castleCollided = true;
            
        }
        if (col.collider.tag == "Enemy")
        {
            
        }

    }
}
