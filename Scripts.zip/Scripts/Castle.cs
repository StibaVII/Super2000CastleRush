﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Castle : MonoBehaviour {

    public float castleHealth = 10f;
    public float castleMaxHP = 10f;
    public GameObject gameOverPanel;
    public bool dead = false;
    public float playerGold = 10f;
    public Text goldText;
    public Text healthText;
    public Text fullAmount;
    public Text moreHpAmount;
    float arrowCost = 10;
    public Text moreDmgAmount;
    float maxhpCost = 15;
    public GameObject arrow;
    public GameObject scripts;
    public GameObject broken;

	// Use this for initialization
	void Start () {
        Arrow Script1 = arrow.GetComponent<Arrow>();
        if (arrowCost <= 10)
        {
            Script1.damage = 2;
        }
        
	}
	
	// Update is called once per frame
	void Update () {
        goldText.text = playerGold.ToString();
        healthText.text = castleHealth.ToString();
        float repairedAmount = castleMaxHP - castleHealth;
        float repairCost = repairedAmount * 3;
        fullAmount.text = repairCost.ToString();
        float fiftypercent = castleMaxHP * 0.5f;

        if (castleHealth <= fiftypercent)
        {
            broken.SetActive(true);
        }

        if (castleHealth > fiftypercent)
        {
            broken.SetActive(false);
        }

        if (castleHealth <= 0)
        {
            dead = true;
            gameOverPanel.SetActive(true);
            Time.timeScale = 0;
            
        }
	}

    public void FullHealth()
    {
        float repairedAmount = castleMaxHP - castleHealth;
        Debug.Log(repairedAmount);
        float repairCost = repairedAmount * 3;
        if (repairCost <= playerGold)
        {
            playerGold = playerGold - repairCost;
            castleHealth = castleHealth + repairedAmount;
        }
    }

    public void MoreMaxHp()
    {
       
       
        if (maxhpCost <= playerGold)
        {
            castleMaxHP = castleMaxHP + 10;
            castleHealth = castleHealth + 10;
            playerGold = playerGold - maxhpCost;
            maxhpCost = maxhpCost * 1.3f;
            maxhpCost = Mathf.Round(maxhpCost);
            moreHpAmount.text = maxhpCost.ToString();
            //amountBought = amountBought + 5;
        }
    }

    public void UpgradeArrow()
    {
        Arrow Script1 = arrow.GetComponent<Arrow>();
        
        if (arrowCost < 50)
        {
            if (arrowCost <= playerGold)
            {
                Script1.damage = Script1.damage + 2;
                playerGold = playerGold - arrowCost;
                arrowCost = arrowCost + 10;
                arrowCost = Mathf.Round(arrowCost);
                moreDmgAmount.text = arrowCost.ToString();

            }
        }
        else if (arrowCost >= 50)
        {
            if (arrowCost <= playerGold)
            {
                Script1.damage = Script1.damage + 2;
                playerGold = playerGold - arrowCost;
                arrowCost = arrowCost * 1.5f;
                arrowCost = Mathf.Round(arrowCost);
                moreDmgAmount.text = arrowCost.ToString();
            }
        }

    }
}
