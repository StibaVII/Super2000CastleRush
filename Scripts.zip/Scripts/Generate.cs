﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Generate : MonoBehaviour {

    public GameObject[] enemies;
    public GameObject[] bosses;
	public GameObject enemySpawn;
    public float scalex = 33f;
    public float scaley = 33f;
    public float speed = 1f;
    float timer;
    public int spawnTimer = 3;
    public float[] waveNumber;
    public float[] enemyNumber;
    public Canvas canvas;
    public float curEnemyNumber = 0f;
    public int nextWave = 0;
	float waveTimer;
    public int waitNextWave = 10;
    GameObject castle;
    public GameObject waitingPanel;
    public Text waitingNumber;
    public GameObject winPanel;
    public float curWave;
    int i = 0;
    public AudioClip bossMusic;

    // Use this for initialization
    void Start()
    {

        
    }

    void Update()
    {
        castle = GameObject.FindGameObjectWithTag("Fort");
        Castle Script1 = castle.GetComponent<Castle>();

        if (Script1.dead == false)
        {
            if (nextWave < waveNumber.Length)
            {
                curWave = waveNumber[nextWave];
                float maxEnemy = enemyNumber[nextWave];

                if (curWave <= waveNumber.Length)
                {
                    timer += Time.deltaTime;
                    spawnTimer = Random.Range(1, 4);
                    if (curEnemyNumber < maxEnemy && timer > spawnTimer)
                    {

                        if (curWave == 10)
                        {
                            GameObject mainCamera = GameObject.FindGameObjectWithTag("MainCamera");
                            AudioSource audiolistener = mainCamera.GetComponent<AudioSource>();
                            audiolistener.clip = bossMusic;
                            audiolistener.Play();
                            float bossAppearingAt = maxEnemy - 1;
                            if (curEnemyNumber == bossAppearingAt)
                            {
                                if (i == 0)
                                {
                                    CreateObstacle3();
                                    curEnemyNumber++;
                                    timer = 0;
                                    i++;
                                }
                            }
                            else
                            {
                                CreateObstacle2();
                                curEnemyNumber++;
                                timer = 0;
                            }
                        }
                        else if (curWave >= 5 && curWave != 10)
                        {
                            CreateObstacle2();
                            curEnemyNumber++;
                            timer = 0;
                        }
                        else if (curWave < 5 && curWave != 10)
                        {
                            CreateObstacle();
                            curEnemyNumber++;
                            timer = 0;
                        }

                    }
                    if (curEnemyNumber == maxEnemy && GameObject.FindGameObjectWithTag("Enemy") == null && GameObject.FindGameObjectWithTag("EnemyFly") == null)
                    {
                        waitingPanel.SetActive(true);
                        float roundedTime = waitNextWave - waveTimer;
                        roundedTime = Mathf.Round(roundedTime);
                        waitingNumber.text = roundedTime.ToString();
                        waveTimer += Time.deltaTime;
                        if (waveTimer > waitNextWave && curWave <= waveNumber.Length)
                        {
                            waitingPanel.SetActive(false);
                            nextWave++;
                            curEnemyNumber = 0;
                            timer = 0;
                            waveTimer = 0;
                        }
                    }
                }
            }
            else
            {
                winPanel.SetActive(true);
                Script1.dead = true;
                Time.timeScale = 0;
            }
        }
    }

    void CreateObstacle()
    {
        int enemyIdentifier = Random.Range(0,2);
        GameObject enemiesSpawned = Instantiate(enemies[enemyIdentifier]);
        Vector3 spawnPosition = new Vector3(enemySpawn.transform.localPosition.x, enemySpawn.transform.localPosition.y);
        Vector3 spawnScale = new Vector3(scalex, scaley);
        enemiesSpawned.transform.SetParent(canvas.transform);
        enemiesSpawned.transform.localPosition = spawnPosition;
        enemiesSpawned.transform.localScale = spawnScale;
    }

    void CreateObstacle2()
    {
        int enemyIdentifier = Random.Range(0, 3);
        GameObject enemiesSpawned = Instantiate(enemies[enemyIdentifier]);
        Vector3 spawnPosition = new Vector3(enemySpawn.transform.localPosition.x, enemySpawn.transform.localPosition.y);
        Vector3 spawnScale = new Vector3(scalex, scaley);
        enemiesSpawned.transform.SetParent(canvas.transform);
        enemiesSpawned.transform.localPosition = spawnPosition;
        enemiesSpawned.transform.localScale = spawnScale;
    }

    void CreateObstacle3()
    {
        int enemyIdentifier = 0;
        GameObject enemiesSpawned = Instantiate(bosses[enemyIdentifier]);
        Vector3 spawnPosition = new Vector3(enemySpawn.transform.localPosition.x, enemySpawn.transform.localPosition.y);
        Vector3 spawnScale = new Vector3(scalex + 5, scaley + 5);
        enemiesSpawned.transform.SetParent(canvas.transform);
        enemiesSpawned.transform.localPosition = spawnPosition;
        enemiesSpawned.transform.localScale = spawnScale;
    }

    public void SkipWait()
    {
        waveTimer = 10000;
    }
}
