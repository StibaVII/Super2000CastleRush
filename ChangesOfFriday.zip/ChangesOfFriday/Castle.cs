﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Castle : MonoBehaviour {

    public float castleHealth = 100f;
    public float castleMaxHP = 100f;
    public GameObject gameOverPanel;
    public bool dead = false;
    public float playerGold = 10f;
    public Text goldText;
    public Text healthText;
    public Text fullAmount;
    float amountBought = 10;
    public Text moreHpAmount;
    float arrowCost = 10;
    public Text moreDmgAmount;
    public GameObject arrow;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        goldText.text = playerGold.ToString();
        healthText.text = castleHealth.ToString();
        float repairedAmount = castleMaxHP - castleHealth;
        float repairCost = repairedAmount * 3;
        fullAmount.text = repairCost.ToString();
        float maxhpCost = amountBought * 1.5f;
        maxhpCost = Mathf.Round(maxhpCost);
        moreHpAmount.text = maxhpCost.ToString();
        if (castleHealth <= 0)
        {
            dead = true;
            gameOverPanel.SetActive(true);
            Time.timeScale = 0;
            
        }
	}

    public void FullHealth()
    {
        float repairedAmount = castleMaxHP - castleHealth;
        Debug.Log(repairedAmount);
        float repairCost = repairedAmount * 3;
        if (repairCost <= playerGold)
        {
            playerGold = playerGold - repairCost;
            castleHealth = castleHealth + repairedAmount;
        }
    }

    public void MoreMaxHp()
    {
        
        float maxhpCost = amountBought * 1.5f;
        maxhpCost = Mathf.Round(maxhpCost);
        if (maxhpCost <= playerGold)
        {
            castleMaxHP = castleMaxHP + 10;
            castleHealth = castleHealth + 10;
            playerGold = playerGold - maxhpCost;
            amountBought = amountBought + 5;
        }
    }

    public void UpgradeArrow()
    {
        Arrow Script1 = arrow.GetComponent<Arrow>();
        if (arrowCost < 50)
        {
            if (arrowCost <= playerGold)
            {
                Script1.damage = Script1.damage + 2;
                playerGold = playerGold - arrowCost;
                arrowCost = arrowCost + 10;
                moreDmgAmount.text = arrowCost.ToString();

            }
        }
        else if (arrowCost >= 50)
        {
            if (arrowCost <= playerGold)
            {
                Script1.damage = Script1.damage + 2;
                playerGold = playerGold - arrowCost;
                arrowCost = arrowCost * 1.5f;
                moreDmgAmount.text = arrowCost.ToString();
            }
        }

    }
}
